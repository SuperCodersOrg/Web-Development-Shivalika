const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = 3000;

const dataFile = path.join(__dirname, "data.json");
app.use(express.json());
app.use(function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") {
        return res.sendStatus(204);
    }
    next();
});

app.get("/", function(req, res) {
    res.sendFile(path.join(__dirname, "../frontend/index.html"));
});
app.get("/style.css", function(req, res) {
    res.sendFile(path.join(__dirname, "../frontend/style.css"));
});
app.get("/script.js", function(req, res) {
    res.sendFile(path.join(__dirname, "../frontend/script.js"));
});

app.get("/home", function (req, res) {
    res.json({message: "Welcome to ABC College"});
});

app.get("/about", function (req, res) {
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        res.json(collegeData.college);
    });
});

app.get("/courses", function (req, res) {
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        res.json({courses: collegeData.courses});
    });
});

app.get("/courses/:course", function (req, res) {
    const courseName = req.params.course;
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        if (courseName === "bca") {
            return res.json(collegeData.bca);
        }
        if (courseName === "btech") {
            return res.json(collegeData.btech);
        }
        res.status(404).json({ success: false, message: "Course not found"});
    });
});

app.get("/students", function (req, res) {
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({success: false,message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        res.json(collegeData.students);
    });
});

app.post("/students", function (req, res) {
    const student = req.body;
    if (!student.name || !student.rollNumber || !student.course) {
        return res.status(400).json({success: false,message: "All fields are required"});
    }
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({success: false,message: "Unable to read data"});
        }
        let collegeData;
        try {
            collegeData = JSON.parse(data);
        }
        catch (error) {
            return res.status(500).json({success: false,message: "Invalid data file"});
        }
        const existingStudent =collegeData.students.registeredStudents.find(function (item) {
                return item.rollNumber === student.rollNumber;});
        if (existingStudent) {
            return res.status(409).json({success: false,message: "Roll number already exists"});
        }
        collegeData.students.registeredStudents.push({name: student.name,rollNumber: student.rollNumber,course: student.course});
        fs.writeFile(dataFile,JSON.stringify(collegeData, null, 4),function (err) {
                if (err) {
                    return res.status(500).json({success: false,message: "Unable to register student"});
                }
                res.status(201).json({success: true,message: "Student registered successfully",student: student});
            }
        );
    });
});

app.get("/facilities", function (req, res) {
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        res.json({facilities: collegeData.facilities});
    });
});

app.get("/placement", function (req, res) {
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        res.json(collegeData.placement);
    });
});

app.get("/contact", function (req, res) {
    fs.readFile(dataFile, "utf8", function (err, data) {
        if (err) {
            return res.status(500).json({message: "Unable to read data"});
        }
        const collegeData = JSON.parse(data);
        res.json(collegeData.contact);
    });
});

app.use(function (req, res) {
    res.status(404).json({success: false,message: "Route not found"});
});

app.listen(PORT, function () {
    console.log("Server running at http://localhost:" + PORT);
});
