const API = "http://localhost:3000";
const navbar = document.getElementById("navbar");
const content = document.getElementById("content");
navbar.addEventListener("click", function (event) {
    if (event.target.tagName === "BUTTON") {
        const page = event.target.dataset.page;
        loadPage(page);
    }
});

function loadPage(page) {
    if (page === "home") {
        home();
    }
    else if (page === "about") {
        about();
    }
    else if (page === "courses") {
        courses();
    }
    else if (page === "students") {
        students();
    }
    else if (page === "register") {
        registerStudent();
    }
    else if (page === "facilities") {
        facilities();
    }
    else if (page === "placement") {
        placement();
    }
    else if (page === "contact") {
        contact();
    }
}


function home() {
    fetch(API + "/home")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            content.innerHTML = `<h2>${data.message}</h2>`;
        })
        .catch(function (error) {
            console.log(error);
        });
}

function about() {
    fetch(API + "/about")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            content.innerHTML = `<h2>${data.name}</h2>
                <p><strong>Established:</strong>${data.established}</p>
                <p><strong>Location:</strong>${data.location}</p>`;
        })
        .catch(function (error) {
            console.log(error);
        });
}

function courses() {
    fetch(API + "/courses")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let html = `<h2>Available Courses</h2><ul>`;
            data.courses.forEach(function (course) {
                html += `<li>${course}</li>`;
            });
            html += `</ul>
                <div class="course-buttons"><button data-course="bca">BCA Details</button>
                <button data-course="btech">B.Tech Details</button></div>`;
            content.innerHTML = html;
        })
        .catch(function (error) {
            console.log(error);
        });
}

content.addEventListener("click", function (event) {
    const course = event.target.dataset.course;
    if (course === "bca") {
        bca();
    }
    else if (course === "btech") {
        btech();
    }
});

function bca() {
    fetch(API + "/courses/bca")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            content.innerHTML = `<h2>${data.course}</h2>
                <p><strong>Duration:</strong>${data.duration}</p>
                <p><strong>Description:</strong>${data.description}</p>`;
        })
        .catch(function (error) {
            console.log(error);
        });
}

function btech() {
    fetch(API + "/courses/btech")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            content.innerHTML = `<h2>${data.course}</h2>
                <p><strong>Duration:</strong>${data.duration}</p>
                <p><strong>Branch:</strong>${data.branch}</p>`;
        })
        .catch(function (error) {
            console.log(error);
        });
}

function students() {
    fetch(API + "/students")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let html = `<h2>Student Information</h2>
                <p><strong>Total Students:</strong>${data.totalStudents}</p>
                <p><strong>Active Batches:</strong>${data.activeBatches}</p>
                <h3>Registered Students</h3>
                <table border="1">
                    <tr>
                        <th>Name</th>
                        <th>Roll Number</th>
                        <th>Course</th>
                    </tr>`;
            data.registeredStudents.forEach(function (student) {
                html += `<tr>
                        <td>${student.name}</td>
                        <td>${student.rollNumber}</td>
                        <td>${student.course}</td>
                    </tr>`;
            });
            html += `</table>`;
            content.innerHTML = html;
        })
        .catch(function (error) {
            console.log("Students Error:", error);
            content.innerHTML = `<h2>Unable to load students</h2>`;
        });
}

function registerStudent() {
    content.innerHTML = `
        <h2>Register Student</h2>
        <form id="studentForm">
            <label>Student Name:</label>
            <input type="text" id="studentName">
            <br><br>
            <label>Roll Number:</label>
            <input type="text"id="rollNumber">
            <br><br>
            <label>Course:</label>
            <input type="text" id="studentCourse">
            <br><br>
            <button type="submit">Register Student</button>
        </form>`;
    const form = document.getElementById("studentForm");
    form.addEventListener("submit", function (event) {
        event.preventDefault();
        const student = {
            name: document.getElementById("studentName").value.trim(),
            rollNumber: document.getElementById("rollNumber").value.trim(),
            course: document.getElementById("studentCourse").value.trim()
        };
        if (!student.name ||!student.rollNumber ||!student.course) {
            alert("Please fill all fields");
            return;
        }
        fetch(API + "/students", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(student)
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            if (data.success) {
                alert(data.message);
                form.reset();
            }
            else {
                alert(data.message);
            }
        })
        .catch(function (error) {
            console.log(error);
            alert("Unable to connect to server");
        });
    });
}

function facilities() {
    fetch(API + "/facilities")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let html = `<h2>College Facilities</h2><ul>`;
            data.facilities.forEach(function (facility) {
                html += `<li>${facility}</li>`;
            });
            html += `</ul>`;
            content.innerHTML = html;
        })
        .catch(function (error) {
            console.log(error);
        });
}

function placement() {
    fetch(API + "/placement")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            content.innerHTML = `<h2>Placement Information</h2>
                <p><strong>Placement Rate:</strong>${data.placementRate}</p>
                <p><strong>Highest Package:</strong>${data.highestPackage}</p>
                <p><strong>Average Package:</strong>${data.averagePackage}</p>`;
        })
        .catch(function (error) {
            console.log(error);
        });
}

function contact() {
    fetch(API + "/contact")
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            content.innerHTML = `<h2>Contact Information</h2>
                <p><strong>Phone:</strong>${data.phone}</p>
                <p><strong>Email:</strong>${data.email}</p>
                <p><strong>Location:</strong>${data.location}</p>`;
        })
        .catch(function (error) {
            console.log(error);
        });
}