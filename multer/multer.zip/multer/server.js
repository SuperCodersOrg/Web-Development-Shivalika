const express = require("express");
const multer = require("multer");
const app = express();
app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));
const upload = multer({
    dest: "uploads/"
});

// app.post('/upload', upload.single('file'), function (req, res) {
//     console.log(req.file);
//      res.send(`
//         <h2>Image uploaded successfully</h2>
//         <img src="/uploads/${req.file.filename}" width="300">
//     `);
// });

app.post('/upload', upload.array('photos', 12), function(req, res){
    console.log(req.photos);
    let images = "";
    req.photos.forEach(function (photo) {
        images += `
            <img
                src="/uploads/${photo.filename}"
                width="250"
                style="margin:10px;"
            >
            `;});
            res.send(`<h2>Images uploaded successfully</h2>${images}`);
})

app.listen(3000, ()=>{
 console.log("server is runing");
});