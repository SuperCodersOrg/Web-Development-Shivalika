const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const fs = require("fs");
const authMiddleware = require("../middleware/authMiddleware");
const sendResetEmail = require("../utils/email");
const router = express.Router();
const dataFile = "./data.json";

function readData() {
    const data = fs.readFileSync(dataFile,"utf-8");
    return JSON.parse(data);
}

function saveData(data) {fs.writeFileSync(dataFile,JSON.stringify(data, null, 2));
}


router.post("/signup", async function (req, res) {
    try {
        const { name,email,password} = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                message: "All fields are required"
            });
        }
        const data = readData();
        const existingUser = data.users.find(
            function (user) {
                return user.email === email;
            }
        );
        if (existingUser) {
            return res.status(409).json({
                message:"User already registered"
            });
        }
        const hashedPassword =await bcrypt.hash(password,10);

        const newUser = {
            id: Date.now(),
            name: name,
            email: email,
            password: hashedPassword,
            resetToken: null,
            resetTokenExpiry: null
        };
        data.users.push(newUser);
        saveData(data);
        res.status(201).json({
            message:"Registration successful",redirect:"login.html"});
    } catch (error) {
        console.log(error);
        res.status(500).json({
            message:"Server error"
        });
    }
});


router.post("/login", async function (req, res) {
    try {
        const {email,password} = req.body;
        const data = readData();
        const user = data.users.find(
            function (user) {     
                 return user.email === email;
            }
        );
        if (!user) {
            return res.status(404).json({
                message:"User is not registered",
                redirect:"signup.html"
            });
        }
        const passwordMatch =await bcrypt.compare(password,user.password);

        if (!passwordMatch) {
            return res.status(401).json({
                message:"Incorrect password"
            });
        }

        const token =jwt.sign({
                    id: user.id,
                    email: user.email
                },
                process.env.JWT_SECRET,
                { expiresIn: "1h"  }
            );
        res.json({
            message:"Login successful",
            token: token,
            user: {name: user.name,email: user.email }
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            message:"Server error"
        });
    }
});


router.post("/forgot-password",async function (req, res) {
        try {
            const { email } = req.body;
            const data = readData();
            const user = data.users.find(
                function (user) {
                    return user.email === email;
                }
            );
            if (!user) {
                return res.status(404).json({
                    message:
                        "Email is not registered"
                });
            }

            const resetToken =crypto.randomBytes(32).toString("hex");
            const expiry =Date.now() +10 * 60 * 1000;
            user.resetToken =resetToken;
            user.resetTokenExpiry =expiry;
            saveData(data);
            const resetLink =`${process.env.FRONTEND_URL}/reset-password.html?token=${resetToken}`;
            await sendResetEmail(email,resetLink);
            res.json({
                message:"Reset link sent to your email"});
        } catch (error) {
            console.log(error);
            res.status(500).json({
                message: "Could not send reset email"});        }
    }
);

router.post("/reset-password",async function (req, res) {
        try {
            const {token,newPassword,confirmPassword} = req.body;
            if ( !token ||  !newPassword ||!confirmPassword) {
                return res.status(400).json({ message:"All fields are required"   });
            }
            if (newPassword !==confirmPassword) {
                return res.status(400).json({
                    message:"Passwords do not match"
                });
            }
            const data = readData();
            const user = data.users.find(
                function (user) {
                    return ( user.resetToken === token);
                }
            );
            if (!user) {
                return res.status(400).json({
                    message:"Invalid reset token"});
            }
            if (Date.now() >user.resetTokenExpiry) {
                return res.status(400).json({
                    message:"Reset link has expired"});
            }
            const hashedPassword =await bcrypt.hash(newPassword,10);
            user.password =hashedPassword;
            user.resetToken = null;
            user.resetTokenExpiry = null;
            saveData(data);
            res.json({
                message:"Password changed successfully"});
        } catch (error) {
            console.log(error);
            res.status(500).json({message:"Server error"});
        }
    }
);

router.get("/profile",authMiddleware,function (req, res) {
        const data = readData();
        const user = data.users.find(
            function (user) {
                return ( user.id === req.user.id );
          }
        );
        if (!user) {
            return res.status(404).json({ message:"User not found"
            });
        }
        res.json({
            name:user.name,
            email:user.email});
    }
);


module.exports = router;