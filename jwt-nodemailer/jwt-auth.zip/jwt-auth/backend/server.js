const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();
const authRoutes = require("./routes/authRoutes");

const app = express();

app.use(cors());

app.use(express.json());

app.use( "/auth",authRoutes);

app.get("/", function (req, res) {
    res.send("Server is running");
});

app.listen(process.env.PORT,function () {

        console.log(
            `Server running on http://localhost:${process.env.PORT}`
        );
    }
);