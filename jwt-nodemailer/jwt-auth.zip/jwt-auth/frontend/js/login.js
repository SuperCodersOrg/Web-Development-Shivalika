const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit",async function (event) {
        event.preventDefault();
        const email = document.getElementById( "email" ).value;
        const password =document.getElementById( "password").value;
        const response =
            await fetch( "http://localhost:3000/auth/login",{
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        email, password
                  })
                }
            );
        const data = await response.json();
        document.getElementById("message" ).innerText =data.message;
        if (response.ok) {
            localStorage.setItem("token",data.token);
            window.location.href ="dashboard.html";
        }
       else if ( response.status === 404) {
            setTimeout(
                function () {
                    window.location.href ="signup.html";
                }, 1000 );
        }

    }
);