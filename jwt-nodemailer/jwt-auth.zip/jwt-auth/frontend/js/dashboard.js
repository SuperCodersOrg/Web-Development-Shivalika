const token =localStorage.getItem("token");


if (!token) {
    window.location.href ="login.html";
}

async function getProfile() {
    const response =
        await fetch("http://localhost:3000/auth/profile",{
                method: "GET",
                headers: {
                    "Authorization":`Bearer ${token}`
                }
            }
        );

    const data =await response.json();
    if (!response.ok) {
        localStorage.removeItem(
            "token"
        );
        window.location.href ="login.html";
        return;
    }

    document.getElementById("name").innerText = `Welcome ${data.name}`;
    document.getElementById("email").innerText =data.email;
}

getProfile();

document.getElementById("logout").addEventListener("click",function () {
        localStorage.removeItem(
            "token"
        );
        window.location.href ="login.html";
    }
);