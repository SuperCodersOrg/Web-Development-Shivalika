const forgotForm = document.getElementById("forgotForm");

forgotForm.addEventListener("submit",async function (event) {
        event.preventDefault();
        const email =document.getElementById("email").value;
        const response =
            await fetch("http://localhost:3000/auth/forgot-password",{
                    method: "POST",
                    headers: {"Content-Type":"application/json"},
                    body: JSON.stringify({
                        email
                    })
                }
            );


        const data =await response.json();

        document.getElementById( "message").innerText =data.message;
    }
);