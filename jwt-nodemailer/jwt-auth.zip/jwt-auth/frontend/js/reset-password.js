const resetForm =document.getElementById("resetForm");

const params =new URLSearchParams(window.location.search);
const token =params.get("token");
resetForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const newPassword =document.getElementById("newPassword" ).value;
        const confirmPassword = document.getElementById("confirmPassword").value;

        const response =await fetch("http://localhost:3000/auth/reset-password",{
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        token,
                        newPassword,
                        confirmPassword
                    })
                }
            );
        const data =await response.json();

        document.getElementById("message" ).innerText =data.message;
        if (response.ok) {
            setTimeout(
                function () {
                    window.location.href ="login.html";}, 1500);
        }

    }
);