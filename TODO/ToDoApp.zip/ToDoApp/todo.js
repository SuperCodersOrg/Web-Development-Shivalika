const outputbox = document.getElementById("output-box");
let inputbox = document.getElementById("input-box");

inputbox.classList = "flex flex-col m-5 border bg-blue-200 rounded-2xl p-5";

inputbox.innerHTML = `
<input type="text" class="text-3xl w-200 h-20 m-5 border bg-white"
placeholder="Enter Title" id="title-box">

<textarea placeholder="Enter Description"
class="text-2xl bg-white w-200 h-20 m-5 border"
id="description-box"></textarea>

<button class="border bg-blue-600 text-white text-4xl p-6 w-90 rounded-xl ml-50"
onclick="addTask()">
Add to List
</button>
`;
function loadTasks() {
   fetch("http://localhost:3000/tasks")
        .then(function(response) {
            return response.json();
        })
        .then(function(tasks) {
            outputbox.innerHTML = "";
            tasks.forEach(function(task) {
                displaytask(task.id,task.title,task.description,task.date,task.completed);
            });
        })
        .catch(function(error) {
            console.log("Error loading tasks:", error);
        });
}

function addTask() {

    let titlebox = document.getElementById("title-box");
    let descriptionbox = document.getElementById("description-box");

    let titleboxvalue = titlebox.value.trim();
    let descriptionboxvalue = descriptionbox.value.trim();

    if (titleboxvalue === "" || descriptionboxvalue === "") {

        Swal.fire({
            icon: "error",
            title: "Warning",
            text: "Something went wrong!",
            footer: "Please Enter a Valid Title and Description"
        });

        return;
    }
    fetch("http://localhost:3000/tasks", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: titleboxvalue,
            description: descriptionboxvalue
        })
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        console.log(data);
        titlebox.value = "";
        descriptionbox.value = "";
        loadTasks();
    })
    .catch(function(error) {
        console.log("Error adding task:", error);
    });
}

function displaytask(id, titlevalue, descriptionvalue, date, completed) {
    let task = document.createElement("div");
    task.className ="task flex justify-between items-center p-4 mb-3 rounded-lg bg-white shadow";
    let taskInfo = document.createElement("div");
    taskInfo.innerHTML = `<h3 class="font-bold text-lg">${titlevalue}</h3>
        <p>${descriptionvalue}</p>
        <p class="text-sm text-gray-500">${date}</p>`;
    let buttons = document.createElement("div");
    buttons.className = "flex gap-2";
    let completeButton = document.createElement("button");
    completeButton.innerText = completed ? "Undo" : "Complete";
    completeButton.className ="px-3 py-2 rounded bg-green-500 text-white";
    completeButton.addEventListener("click", function() {
        toggleTask(id, completed);
    });

    let editButton = document.createElement("button");
    editButton.innerText = "Edit";
    editButton.className ="px-3 py-2 rounded bg-blue-500 text-white";
    editButton.addEventListener("click", function() {
        editTask(id, titlevalue, descriptionvalue);
    });

    let deleteButton = document.createElement("button");
    deleteButton.innerText = "Delete";
    deleteButton.className ="px-3 py-2 rounded bg-red-500 text-white";
    deleteButton.addEventListener("click", function() {
        deletetask(id);
    });
    buttons.appendChild(completeButton);
    buttons.appendChild(editButton);
    buttons.appendChild(deleteButton);
    task.appendChild(taskInfo);
    task.appendChild(buttons);
    outputbox.appendChild(task);
}

function deletetask(id) {
    fetch(`http://localhost:3000/tasks/${id}`, {
        method: "DELETE"
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        console.log(data);
        loadTasks();
    })
    .catch(function(error) {
        console.log("Error deleting task:", error);
    });
}

function editTask(id, oldTitle, oldDescription) {
    let newTitle = prompt("Enter new title:",oldTitle);
    if (newTitle === null) {
        return;
    }
    let newDescription = prompt("Enter new description:",oldDescription);
    if (newDescription === null) {
        return;
    }
    fetch(`http://localhost:3000/tasks/${id}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: newTitle,
            description: newDescription
        })
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        console.log(data);
        loadTasks();
    })
    .catch(function(error) {
        console.log("Error editing task:", error);
    });
}

function toggleTask(id, currentStatus) {
    fetch(`http://localhost:3000/tasks/${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            completed: !currentStatus
        })
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        console.log(data);
        loadTasks();
    })
    .catch(function(error) {
        console.log("Error updating task:", error);
    });
}

function getTask(id) {
    fetch(`http://localhost:3000/tasks/${id}`)
        .then(function(response) {
            return response.json();
        })
        .then(function(task) {
            console.log(task);
        })
        .catch(function(error) {
            console.log("Error getting task:", error);
        });
}

loadTasks();