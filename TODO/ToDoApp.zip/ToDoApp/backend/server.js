const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = 3000;
const dataFile = path.join(__dirname, "data.json");
const frontendPath = path.join(__dirname, "../frontend");
app.use(express.json());
app.use(function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods","GET, POST, PUT, PATCH, DELETE");
    res.setHeader("Access-Control-Allow-Headers","Content-Type");
    next();
});

app.get("/", function (req, res) {
    fs.readFile(path.join(frontendPath, "index.html"),"utf8",function (err, data) {
            if (err) {
                res.status(500).send("Unable to load HTML");
                return;
            }
            res.send(data);
        }
    );
});

app.get("/todo.js", function (req, res) {
    fs.readFile(path.join(frontendPath, "todo.js"),"utf8",function (err, data) {
            if (err) {
                res.status(500).send("Unable to load JavaScript");
                return;
            }
            res.type("application/javascript");
            res.send(data);
        }
    );
});

app.get("/tasks", function (req, res) {
    fs.readFile(dataFile,"utf8",function (err, data) {
            if (err) {
                res.status(500).json({message: "Unable to read tasks"});
                return;
            }
            let tasks = JSON.parse(data);
            res.json(tasks);
        }
    );
});

app.post("/tasks", function (req, res) {
    fs.readFile(dataFile,"utf8",function (err, data) {
            if (err) {
                res.status(500).json({message: "Unable to read data"});
                return;
            }
            let tasks = JSON.parse(data);
            let task = {id: Date.now(),title: req.body.title,description: req.body.description,date: new Date().toLocaleString(),completed: false};
            tasks.push(task);
            fs.writeFile(dataFile,JSON.stringify(tasks, null, 4),function (err) {
                    if (err) {
                        res.status(500).json({message: "Unable to save task"});
                        return;
                    }
                    res.status(201).json({message: "Task added successfully",task: task});
                }
            );
        }
    );
});

app.put("/tasks/:id", function (req, res) {
    let id = Number(req.params.id);
    fs.readFile(dataFile,"utf8",function (err, data) {
            if (err) {
                res.status(500).json({message: "Unable to read data"});
                return;
            }
            let tasks = JSON.parse(data);
            let task = tasks.find(function (task) {
                return task.id === id;
            });
            if (!task) {
                res.status(404).json({message: "Task not found"});
                return;
            }
            task.completed = req.body.completed;
            fs.writeFile(dataFile,JSON.stringify(tasks, null, 4),function (err) {
                    if (err) {
                        res.status(500).json({message: "Unable to update task"});
                        return;
                    }
                    res.json({message: "Task status updated",task: task});
                }
            );
        }
    );
});

app.patch("/tasks/:id", function (req, res) {
    let id = Number(req.params.id);
    fs.readFile(dataFile,"utf8",function (err, data) {
            if (err) {
                res.status(500).json({message: "Unable to read data"});
                return;
            }
            let tasks = JSON.parse(data);
            let task = tasks.find(function (task) {
                return task.id === id;
            });
            if (!task) {
                res.status(404).json({message: "Task not found"});
                return;
            }
            if (req.body.title !== undefined) {
                task.title = req.body.title;
            }
            if (req.body.description !== undefined) {
                task.description = req.body.description;
            }
            task.date = new Date().toLocaleString();
            fs.writeFile(dataFile,JSON.stringify(tasks, null, 4),function (err) {
                    if (err) {
                        res.status(500).json({message: "Unable to edit task"});
                        return;
                    }
                    res.json({message: "Task edited successfully",task: task});
                }
            );
        }
    );
});

app.delete("/tasks/:id", function (req, res) {
    let id = Number(req.params.id);
    fs.readFile(dataFile,"utf8",function (err, data) {
            if (err) {
                res.status(500).json({message: "Unable to read data"});
                return;
            }
            let tasks = JSON.parse(data);
            let newTasks = tasks.filter(function (task) {return task.id !== id;});
            if (newTasks.length === tasks.length) {
                res.status(404).json({message: "Task not found"});
                return;
            }
            fs.writeFile(dataFile,JSON.stringify(newTasks, null, 4),function (err) {
                    if (err) {
                        res.status(500).json({message: "Unable to delete task"});
                        return;
                    }
                    res.json({message: "Task deleted successfully"});
                }
            );
        }
    );
});


app.listen(PORT, function () {
    console.log(`Server running at http://localhost:${PORT}`);
});