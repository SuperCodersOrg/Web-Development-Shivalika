const http = require("http");
const fs = require("fs");
const PORT = 3000;

const server = http.createServer(function (req, res) {
    res.setHeader("Access-Control-Allow-Origin","*");
    res.setHeader("Access-Control-Allow-Methods","GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers","Content-Type");
    if (req.method === "OPTIONS") {
        res.writeHead(204);
        res.end();
        return;
    }
    if (req.method === "GET" && req.url === "/") {
        res.writeHead(200, {"Content-Type": "application/json"});
        res.end(JSON.stringify({message: "Welcome to ABC College"}));
        return;
    }
    if (req.method === "GET" && req.url === "/about") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
    const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify(collegeData.college));
            }
        );
        return;
    }
    if (req.method === "GET" && req.url === "/courses") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
                const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify({courses: collegeData.courses}));
        });
        return;
    }
    if (req.method === "GET" &&req.url === "/courses/bca") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
    const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify(collegeData.bca));
            });
        return;
    }
    if (req.method === "GET" &&req.url === "/courses/btech") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
    const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify(collegeData.btech));
            });
        return;
    }
    if (req.method === "GET" &&req.url === "/students") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({success: false,message: "Unable to read data"}));
                    return;
                }
    const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify(collegeData.students));
        });
        return;
    }
    if (req.method === "POST" &&req.url === "/students") {
        let body = "";
        req.on("data", function (chunk) {
            body += chunk;
        });
        req.on("end", function () {
            let student;
            try {
                student = JSON.parse(body);
            }
            catch (error) {
                res.writeHead(400, {"Content-Type": "application/json"});
                res.end(JSON.stringify({success: false,message: "Invalid JSON"}));
                return;
            }
            if (!student.name ||!student.rollNumber ||!student.course) {
                res.writeHead(400, {"Content-Type": "application/json"});
                res.end(JSON.stringify({success: false,message: "All fields are required"}));
                return;
            }
            fs.readFile("./data.json","utf8",function (err, data) {
                    if (err) {
                        res.writeHead(500, {"Content-Type": "application/json"});
                        res.end(JSON.stringify({success: false,message: "Unable to read data"}));
                        return;
                    }
    let collegeData;
                try {
                        collegeData = JSON.parse(data);
                    }
                    catch (error) {
                        res.writeHead(500, {"Content-Type": "application/json"});
                        res.end(JSON.stringify({success: false,message: "Invalid data file"}));
                        return;
                    }
    const existingStudent =collegeData.students.registeredStudents.find(function (item) {
                                return (item.rollNumber ===student.rollNumber);
                            });
                    if (existingStudent) {
                        res.writeHead(409, {"Content-Type": "application/json"});
                        res.end(JSON.stringify({success: false,message: "Roll number already exists"}));
                        return;
                    }
    collegeData.students.registeredStudents.push({name: student.name,rollNumber: student.rollNumber,course: student.course});
                    fs.writeFile("./data.json",JSON.stringify(collegeData,null,4),function (err) {
                            if (err) {
                                res.writeHead(500, {"Content-Type":"application/json"});
                                res.end(JSON.stringify({success: false,message:"Unable to register student"}));
                                return;
                            }
                            res.writeHead(201, {"Content-Type":"application/json"});
                            res.end(JSON.stringify({success: true,message:"Student registered successfully",student: student}));
                        }
                    );
                }
            );
        });
        return;
    }
    if (req.method === "GET" &&req.url === "/facilities") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
                const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify({facilities:collegeData.facilities}));
            }
        );
        return;
    }
    if (req.method === "GET" &&req.url === "/placement") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
                const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify(collegeData.placement));
            }
        );
        return;
    }
    if (req.method === "GET" &&req.url === "/contact") {
        fs.readFile("./data.json","utf8",function (err, data) {
                if (err) {
                    res.writeHead(500, {"Content-Type": "application/json"});
                    res.end(JSON.stringify({message: "Unable to read data"}));
                    return;
                }
    const collegeData = JSON.parse(data);
                res.writeHead(200, {"Content-Type": "application/json"});
                res.end(JSON.stringify(collegeData.contact));
            }
        );
        return;
    }
    res.writeHead(404, {"Content-Type": "application/json"});
    res.end(JSON.stringify({success: false,message: "Route not found"}));
});


server.listen(PORT, function () {
    console.log("Server running at http://localhost:" + PORT);
});