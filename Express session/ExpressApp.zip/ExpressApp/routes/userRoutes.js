const express = require("express");
const checkAuth = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/dashboard", checkAuth, function(req, res) {

    res.json({
        success: true,
        message: "Welcome to dashboard",
        user: req.session.user
    });

});

module.exports = router;