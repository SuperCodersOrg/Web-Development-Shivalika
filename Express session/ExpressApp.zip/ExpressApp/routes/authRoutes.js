const express = require("express");

const router = express.Router();

let users = [];


router.post("/register", function(req, res) {

    const username = req.body.username;
    const password = req.body.password;

    const existingUser = users.find(function(user) {
        return user.username === username;
    });

    if (existingUser) {
        return res.json({
            success: false,
            message: "User already exists"
        });
    }

    users.push({
        username: username,
        password: password
    });

    res.json({
        success: true,
        message: "Registration successful"
    });
});


router.post("/login", function(req, res) {

    const username = req.body.username;
    const password = req.body.password;

    const user = users.find(function(user) {
        return user.username === username &&
               user.password === password;
    });

    if (!user) {
        return res.json({
            success: false,
            message: "Invalid username or password"
        });
    }

    req.session.user = {
        username: user.username
    };

    res.json({
        success: true,
        message: "Login successful"
    });
});


router.get("/logout", function(req, res) {

    req.session.destroy(function(err) {

        if (err) {
            return res.json({
                success: false,
                message: "Logout failed"
            });
        }

        res.redirect("/login.html");
    });

});


module.exports = router;