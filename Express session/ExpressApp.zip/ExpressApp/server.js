const express = require("express");
const session = require("express-session");

const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"));

app.use(
    session({
        secret: "mySecretKey",
        resave: false,
        saveUninitialized: false
    })
);

app.use("/auth", authRoutes);
app.use("/user", userRoutes);

app.get("/", function (req, res) {
    res.redirect("/login.html");
});

app.listen(3000, function () {
    console.log("Server running at http://localhost:3000");
});